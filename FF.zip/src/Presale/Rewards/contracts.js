// src/Presale/Rewards/contracts.js

import { CONTRACTS } from '../../contract/contracts'; // Import corect centralizat

export const TELEGRAM_REWARD_CONTRACT = CONTRACTS.TELEGRAM_REWARD;
export const ADDITIONAL_REWARD_CONTRACT = CONTRACTS.ADDITIONAL_REWARD;
