// DEPRECATED: Use contractMap.js instead
export { getCellManagerContract } from './contractMap.js';
