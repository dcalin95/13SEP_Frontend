// DEPRECATED: Use contractMap.js instead
export { getBITSContract } from './contractMap.js';

