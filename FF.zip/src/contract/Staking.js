// DEPRECATED: Use contractMap.js instead  
export { getStakingContract } from './contractMap.js';

