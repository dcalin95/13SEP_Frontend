// DEPRECATED: Use contractMap.js instead
export { getAdditionalRewardContract } from './contractMap.js';
