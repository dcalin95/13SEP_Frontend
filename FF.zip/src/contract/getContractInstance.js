// DEPRECATED: Use contractMap.js instead
// This file is kept for backward compatibility
export { getContractInstance } from './contractMap.js';
