// DEPRECATED: Use src/contract/contractMap.js instead
// This file is kept for backward compatibility but should be migrated
export { CONTRACT_MAP as CONTRACTS } from './contractMap.js';


