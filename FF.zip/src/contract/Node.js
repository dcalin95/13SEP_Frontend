// DEPRECATED: Use contractMap.js instead
export { getNodeContract } from './contractMap.js';

// Backward compatibility for the old function name
export { getNodeContract as getContract } from './contractMap.js';