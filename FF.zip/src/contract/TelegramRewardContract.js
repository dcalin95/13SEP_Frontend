// DEPRECATED: Use contractMap.js instead
export { getTelegramRewardContract } from './contractMap.js';

// Backward compatibility for the old function name (with double 'Contract')
export { getTelegramRewardContract as getTelegramRewardContractContract } from './contractMap.js';

