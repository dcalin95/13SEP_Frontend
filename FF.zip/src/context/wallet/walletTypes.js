export const WALLET_TYPES = {
    EVM: "EVM",
    SOLANA: "Solana",
    TORUS: "torus",
    WALLETCONNECT: "walletconnect",
    COINBASE: "coinbase",
    RAINBOW: "rainbow",
  };
  

